package com.dto;

import java.util.Date;



public class AppointmentDto {
	
	private Integer appId;
	
	
	private Integer patientId;
	private Integer doctorId;
	private Date appointment_date;
	public Integer getAppId() {
		return appId;
	}
	public void setAppId(Integer appId) {
		this.appId = appId;
	}
	public Integer getPatientId() {
		return patientId;
	}
	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}
	public Integer getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}
	public Date getAppointment_date() {
		return appointment_date;
	}
	public void setAppointment_date(Date appointment_date) {
		this.appointment_date = appointment_date;
	}
	public AppointmentDto(Integer appId, Integer patientId, Integer doctorId, Date appointment_date) {
		super();
		this.appId = appId;
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.appointment_date = appointment_date;
	}

	

}
