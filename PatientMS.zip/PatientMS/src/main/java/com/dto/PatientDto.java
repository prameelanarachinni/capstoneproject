package com.dto;

public class PatientDto {
	
	
	
	private Integer patient_Id;
	private String patient_name;
	private String gender;
	public Integer getPatient_Id() {
		return patient_Id;
	}
	public void setPatient_Id(Integer patient_Id) {
		this.patient_Id = patient_Id;
	}
	public String getPatient_name() {
		return patient_name;
	}
	public void setPatient_name(String patient_name) {
		this.patient_name = patient_name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public PatientDto(Integer patient_Id, String patient_name, String gender) {
		super();
		this.patient_Id = patient_Id;
		this.patient_name = patient_name;
		this.gender = gender;
	}
	public Object getPatientName() {
		// TODO Auto-generated method stub
		return null;
	}
	public Iterable<Long> getEmail() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getDateOfBirth() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getAddress() {
		// TODO Auto-generated method stub
		return null;
	}
}
    