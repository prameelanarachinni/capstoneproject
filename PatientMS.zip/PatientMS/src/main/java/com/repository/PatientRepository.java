package com.repository;
import org.springframework.data.repository.CrudRepository;

import com.dto.PatientDto;
import com.model.Patient;

import jakarta.validation.Valid;

public interface PatientRepository extends CrudRepository<Patient, Long> {
    static Patient findByEmail(Iterable<Long> iterable) {
		// TODO Auto-generated method stub
		return null;
	}

	static void save(@Valid PatientDto patientDto) {
		// TODO Auto-generated method stub
		
	}
}




		
	





