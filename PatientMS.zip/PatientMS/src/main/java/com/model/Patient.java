package com.model;
import java.util.Date;

import com.dto.PatientDto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name="patient")
public class Patient {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="patient_id")
	private Integer patientId;
	
	@Column(name="patient_name")
	@NotEmpty(message="name  is missing")
	private String patientname;
	
	@Column(name="gender")
	@NotEmpty(message="gender  is manadatory")
	private String gender;
	
	
	
	
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Patient(Integer patientId, @NotEmpty(message = "name  is missing") String patientname,
			@NotEmpty(message = "gender  is manadatory") String gender,
			@NotNull(message = "date_of_birth is missing") Date dateofbirth,
			@NotEmpty(message = "address  is missing") String address,
			@NotEmpty(message = "email_id  is missing") String emailId,
			@NotEmpty(message = "password  is manadatory") String password) {
		super();
		this.patientId = patientId;
		this.patientname = patientname;
		this.gender = gender;
		this.dateofbirth = dateofbirth;
		this.address = address;
		this.emailId = emailId;
		this.password = password;
	}


	public Integer getPatientId() {
		return patientId;
	}


	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}


	public String getPatientname() {
		return patientname;
	}


	public void setPatientname(String patientname) {
		this.patientname = patientname;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public Date getDateofbirth() {
		return dateofbirth;
	}


	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Column(name="date_of_birth")
    @NotNull(message="date_of_birth is missing")
	private Date dateofbirth;
	

	@Column(name="address")
	@NotEmpty(message="address  is missing")
	private String address;
	

	@Column(name="email_id")
	@NotEmpty(message="email_id  is missing")
	private String emailId;
	

	@Column(name="password")
	@NotEmpty(message="password  is manadatory")
	private String password;

	public void setPatientName(Object patientName2) {
		// TODO Auto-generated method stub
		
	}


	public void setEmail(Object email) {
		// TODO Auto-generated method stub
		
	}


	public void setDateOfBirth(Object dateOfBirth) {
		// TODO Auto-generated method stub
		
	}


	public boolean isPresent() {
		// TODO Auto-generated method stub
		return false;
	}


	public PatientDto get() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	



}
