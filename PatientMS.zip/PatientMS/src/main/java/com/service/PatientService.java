package com.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.PatientDto;
import com.google.common.base.Optional;
import com.model.Patient;

import com.repository.PatientRepository;

import jakarta.validation.Valid;

@Service

public class PatientService {
	@Autowired
	PatientRepository patientRepository;
	
	public void registerPatient(@Valid PatientDto patientDto) {
		Patient patient = new Patient();
        patient.setPatientName(patientDto.getPatientName());
        patient.setEmail(patientDto.getEmail());
        patient.setPassword(patientDto.getPassword()); // Remember to hash passwords in a real application
        patient.setDateOfBirth(patientDto.getDateOfBirth());
        patient.setAddress(patientDto.getAddress());
        patient.setGender(patientDto.getGender());
        PatientRepository.save(patientDto);
    
		
	}

	public static boolean authenticate(PatientDto patientDto) {
        Patient patient = PatientRepository.findByEmail(patientDto.getEmail());
        return patient.isPresent() && patient.get().getPassword().equals(patientDto.getPassword());
    }
}
